# Altcoin Long/Short Discord Bot

Posts a top-20 altcoin long/short table to a Discord channel every 10 minutes.

```
COIN   LONG   L/S    chg   24h
------------------------------
ETH    73.3  2.75  -0.01  2.47 🟢→
XRP    70.9  2.43  -0.07  2.36 🟢→
SOL    69.0  2.22  -0.04  2.14 🟢→
```

| Column | Meaning |
| --- | --- |
| `LONG` | Share of accounts net long, in percent (short is the remainder) |
| `L/S` | Long accounts per short account |
| `chg` | Change in the long share since the previous post, in percentage points |
| `24h` | The L/S ratio 24 hours ago (the `wide` layout adds `1h`) |
| 🟢 / 🔴 / ⚪ | Crowd is long (≥55%), short (≤45%), or balanced |
| ↗ / ↘ / → | Longs building, unwinding, or flat since the last post |

## Setup

1. **Install**

   ```bash
   pip install -r requirements.txt
   ```

2. **Create the Discord bot**

   - <https://discord.com/developers/applications> → *New Application*
   - **Bot** tab → *Reset Token* → copy the token
   - **OAuth2 → URL Generator**: scope `bot`, permissions *View Channel*,
     *Send Messages*, *Embed Links*. Open the generated URL and invite the bot.
   - No privileged intents are needed — Message Content is only required for
     *reading* messages, and this bot only posts.

3. **Get the channel ID**

   Discord → Settings → Advanced → **Developer Mode** on, then right-click the
   target channel → *Copy Channel ID*.

4. **Get a Coinalyze API key** (optional, recommended)

   Sign in at <https://coinalyze.net/> → API page → generate a key. The key is a
   string; `https://api.coinalyze.net/v1/doc/` is the documentation, not a key.
   Without a key the bot runs on Binance alone.

5. **Configure**

   ```bash
   cp .env.example .env
   ```

   Fill in `DISCORD_TOKEN`, `DISCORD_CHANNEL_ID`, and optionally
   `COINALYZE_API_KEY`.

6. **Run**

   Double-click **`start-bot.bat`**, or from a terminal:

   ```bash
   python bot.py
   ```

   The bot only runs while that window is open. See *Starting it automatically*
   below to have Windows launch it at login.

## Checking it without Discord

`--dry-run` prints one table to stdout using live market data. It needs no
token and makes no Discord connection:

```bash
python bot.py --dry-run                    # whatever source is configured
python bot.py --dry-run --source binance   # force the backup
python bot.py --dry-run --source coinalyze # verify a new API key (strict)
```

`--source coinalyze` is **strict**: it fails loudly and exits non-zero instead of
falling back. Use it right after pasting a new key. Without it, a broken key or a
failed symbol lookup just falls back to Binance forever, and the bot looks
healthy while never once using the primary source. (In normal operation that
fallback is logged at WARNING, escalating to ERROR after three consecutive
failures, and the footer says `BACKUP SOURCE`.)

## Layout: mobile vs wide

Discord code blocks do not wrap - anything wider than the screen scrolls
sideways, which is unusable on a phone. Two layouts, set with `LAYOUT` in `.env`:

- **`mobile`** (default, 30 chars) - fits a phone screen.
- **`wide`** (45 chars) - adds an explicit `SHORT` column and a `1h` column.
  Fine on desktop, scrolls sideways on a phone.

`mobile` gives up very little: `SHORT` is always `100 - LONG`, and at a
10-minute cadence `1h` barely differs from the current value, so `24h` is the
column actually carrying history.

Compare them before choosing:

```bash
python bot.py --dry-run --source binance
```

## Data sources

**Primary — Coinalyze** (needs a free key). Coinalyze symbols are per-market,
so each coin is resolved to its perp on Binance, Bybit and OKX and the long
share is averaged across them, approximating the aggregate figure the Coinalyze
site shows. A weighted mean would need per-venue account counts, which no public
API exposes.

Quota is 40 calls/minute and **each symbol counts as one call**. 20 coins × 3
venues = 60 symbols per cycle = 6 calls/minute at a 10-minute cadence.

**Backup — Binance** (no key). Uses `globalLongShortAccountRatio`, the share of
all Binance futures *accounts* net long. Binance also publishes
`topLongShortAccountRatio` and `topLongShortPositionRatio`, which are different
metrics — swapping them changes what the bot reports.

Because the backup is one venue and the primary is a three-venue mean, the
levels shift by a point or so on failover. The footer says which source produced
the table and flags when the backup is in use, so the shift isn't misread as a
market move.

**Coin list — CoinGecko**, refreshed daily and cached to `cache/universe.json`.
BTC, stablecoins and wrapped/staked derivatives are excluded. The list is walked
in market-cap order until 20 coins with a futures market are found; a CoinGecko
failure falls back to the cached list, then to a hardcoded seed.

## Design notes

- **Every time column comes from one fetch.** A single 25-hour history request
  contains the current bar plus the ones 10 minutes, 1 hour and 24 hours back.
  Splitting this into four requests would quadruple quota use for nothing.
- **`chg` is derived from that same series, not from a saved previous post.**
  There is no state file to corrupt, no wrong value on a cold start, and the
  comparison can never straddle a source change.
- **Timestamps are matched, not indexed.** Points are found by proximity to a
  target time and rejected if too far off, so one missing bar at a venue cannot
  silently shift every column by five minutes.
- **A symbol with no data returns an empty history rather than an error**, so
  empty series are treated as missing and the coin is skipped.

## Status

The Binance path and the formatting are verified against live data. **The
Coinalyze path is code-complete but has never been executed** — it needs a key,
so the first run with one is also its first test. Run
`python bot.py --dry-run --source coinalyze` first; if the venue matching or the
market filter needs adjusting, that command says so instead of hiding it behind
a fallback.

## Tuning

`.env` accepts `POST_INTERVAL_MINUTES` (default 10), `TOP_N` (default 20) and
`LAYOUT` (`mobile` or `wide`).
`chg` always compares against one interval back, so changing the interval keeps
the column meaningful.

The coin list is strictly market-cap ranked, so newer top-100 coins (recently
`CC`, `GRAM`) can appear alongside the majors. If you want only recognisable
names, add their CoinGecko ids to `EXCLUDED_IDS` in `universe.py` — no code
change needed.

Thresholds live at the top of `formatter.py`: `LONG_BIAS_PCT`, `SHORT_BIAS_PCT`
and `TREND_EPS_PP`. Venue selection is `PREFERRED_EXCHANGES` in
`sources/coinalyze.py`.

## Hosting it (Pella and similar panels)

Running on a host means it posts 24/7 without your PC being on. `main.py` is the
entry point most panels expect; `python bot.py` is equivalent if you can set a
start command.

Upload **`altcoin-ls-bot-upload.zip`** — it contains the code, `requirements.txt`
and `.env.example`, and deliberately **excludes `.env`** so your token is never
inside a file you might share.

Then, in the panel:

1. **Install dependencies** — most panels do this from `requirements.txt`
   automatically. If there is a "startup"/"install" command field, use
   `pip install -r requirements.txt`.
2. **Set the start command** to `python main.py` (only if the panel asks; many
   default to `main.py` already).
3. **Set the secrets.** Either is fine:
   - an *Environment Variables* / *Secrets* tab in the panel — add
     `DISCORD_TOKEN`, `DISCORD_CHANNEL_ID`, and optionally `COINALYZE_API_KEY`; or
   - create a file named `.env` in the panel's file manager, using
     `.env.example` as the template.

   The bot reads panel variables when they exist and falls back to `.env`, so
   whichever the host offers will work.
4. **Start it**, then read the logs. Success looks like:

   ```
   logged in as YourBot#1234; posting every 10 minutes
   posted 20 rows from Binance
   ```

Notes for any free tier:

- **Python 3.10+ is required.** `main.py` exits with a clear message on anything
  older, rather than failing obscurely.
- **The filesystem may be read-only or wiped on restart.** That is fine: the two
  caches are best-effort and the bot refetches when they are missing.
- **A restart loses nothing.** Nothing is stored between cycles - every column,
  including the change since the last post, is derived from the market history
  fetched in that cycle.
- **Free tiers often idle or restart bots.** This one has no web server to keep
  awake; if the host kills it, it simply resumes posting when restarted.

## Starting it automatically at login (local alternative)

The bot runs only while its window is open. To have Windows start it when you
log in:

1. Right-click **`start-bot.bat`** → **Show more options** → **Create shortcut**.
2. Press <kbd>Win</kbd>+<kbd>R</kbd>, type `shell:startup`, press Enter. The
   Startup folder opens.
3. Drag the shortcut into that folder.

It now launches at every login. A console window stays open while it runs —
minimise it; closing it stops the bot. To undo, delete the shortcut from that
folder.

Note that this starts at **login**, not at boot, and the PC must stay awake. If
you want it running when you are not logged in at all, that is a job for Task
Scheduler ("Run whether user is logged on or not") or a cheap VPS.

## Note

144 posts a day is a lot of channel traffic. Give the bot its own channel.
